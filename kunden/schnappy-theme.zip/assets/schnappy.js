/* Schnappy – interaktive Bausteine (3D-Box, Box-Auswahl, Countdown, Live-Chat, App-Leiste, Glücksrad) */
(() => {
  const RM = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const DESIGN = !!(window.Shopify && window.Shopify.designMode);
  const define = (name, cls) => { if (!customElements.get(name)) customElements.define(name, cls); };

  /* ---------- Reveal (Hero-Überschrift, Zähler) ---------- */
  const countUp = (el) => {
    const t = el.textContent.trim();
    const m = t.match(/^([−-]?)(\d[\d.]*)/);
    if (!m || RM) return;
    const end = parseInt(m[2].replace(/\./g, ''), 10);
    if (!end) return;
    const pre = m[1], rest = t.slice(m[0].length);
    const fmt = (n) => pre + (end >= 1000 ? n.toLocaleString('de-DE') : n) + rest;
    let st = null;
    const step = (ts) => {
      st = st || ts;
      const p = Math.min(1, (ts - st) / 1400), e = 1 - Math.pow(1 - p, 3);
      el.textContent = fmt(Math.round(end * e));
      if (p < 1) requestAnimationFrame(step); else el.textContent = t;
    };
    requestAnimationFrame(step);
  };
  const io = 'IntersectionObserver' in window
    ? new IntersectionObserver((es) => es.forEach((en) => {
        if (!en.isIntersecting) return;
        en.target.classList.add('in');
        if (en.target.hasAttribute('data-sn-count')) countUp(en.target);
        io.unobserve(en.target);
      }), { threshold: 0.12 })
    : null;
  const observeReveal = (root = document) => {
    root.querySelectorAll('.sn-reveal:not(.in), [data-sn-count]:not(.in)').forEach((el) => {
      if (!io || DESIGN) el.classList.add('in'); else io.observe(el);
    });
  };

  /* ---------- 3D-Szene: drehen, ziehen, antippen ---------- */
  class SnScene extends HTMLElement {
    connectedCallback() {
      if (this._on) return;
      this._on = true;
      this.a = parseFloat(this.dataset.start || '-30');
      this.auto = parseFloat(this.dataset.auto || '0.16');
      this.tilt = parseFloat(this.dataset.tilt || '-18');
      this.clickOpen = !this.hasAttribute('data-no-open');
      this.drag = false; this.vis = true; this.touched = false;
      if (this.clickOpen) {
        this.addEventListener('pointerdown', (e) => {
          this.drag = true; this.moved = 0; this.x0 = e.clientX; this.a0 = this.a; this.touched = true;
          try { this.setPointerCapture(e.pointerId); } catch (_) {}
        });
        this.addEventListener('pointermove', (e) => {
          if (!this.drag) return;
          const dx = e.clientX - this.x0;
          this.moved = Math.max(this.moved, Math.abs(dx));
          this.a = this.a0 + dx * 0.45;
        });
        this.addEventListener('pointerup', () => { if (!this.drag) return; this.drag = false; if (this.moved < 6) this.toggle(); });
        this.addEventListener('pointercancel', () => { this.drag = false; });
        this.addEventListener('keydown', (e) => {
          if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); this.touched = true; this.toggle(); }
          if (e.key === 'ArrowLeft') { this.a -= 15; this.touched = true; }
          if (e.key === 'ArrowRight') { this.a += 15; this.touched = true; }
        });
      }
      if ('IntersectionObserver' in window) {
        this.obs = new IntersectionObserver(([en]) => { this.vis = en.isIntersecting; });
        this.obs.observe(this);
      }
      const loop = () => {
        if (this.vis) {
          if (!this.drag && !RM) this.a += this.auto;
          const c = this.cube;
          if (c) c.style.transform = `rotateX(${this.tilt}deg) rotateY(${this.a}deg)`;
        }
        this.raf = requestAnimationFrame(loop);
      };
      loop();
      if (this.hasAttribute('data-autocycle') && !RM) {
        const cyc = () => {
          if (this.touched || !this.vis) return;
          const c = this.cube; if (!c) return;
          c.classList.add('open');
          this.t2 = setTimeout(() => { if (!this.touched) c.classList.remove('open'); }, 3400);
        };
        this.t1 = setTimeout(() => { cyc(); this.iv = setInterval(cyc, 6800); }, 1500);
      }
    }
    get cube() { return this.querySelector(':scope > .sn-cube'); }
    toggle() { const c = this.cube; if (c) c.classList.toggle('open'); }
    disconnectedCallback() {
      this._on = false;
      cancelAnimationFrame(this.raf); clearTimeout(this.t1); clearTimeout(this.t2); clearInterval(this.iv);
      if (this.obs) this.obs.disconnect();
    }
  }
  define('sn-scene', SnScene);

  /* ---------- Box-Auswahl (Reiter S/M/XXL) ---------- */
  class SnBoxPicker extends HTMLElement {
    connectedCallback() {
      this.tabs = [...this.querySelectorAll('.sn-tab')];
      if (!this.tabs.length) return;
      this.tabs.forEach((t, i) => {
        t.addEventListener('click', () => this.select(i));
        t.addEventListener('keydown', (e) => {
          const d = e.key === 'ArrowRight' ? 1 : e.key === 'ArrowLeft' ? -1 : 0;
          if (!d) return;
          e.preventDefault();
          const n = (i + d + this.tabs.length) % this.tabs.length;
          this.select(n); this.tabs[n].focus();
        });
      });
    }
    select(i) {
      const tab = this.tabs[i];
      this.tabs.forEach((t, j) => {
        const on = j === i;
        t.setAttribute('aria-selected', on ? 'true' : 'false');
        t.tabIndex = on ? 0 : -1;
        const p = document.getElementById(t.getAttribute('aria-controls'));
        if (p) p.hidden = !on;
      });
      const [w, h, d] = (tab.dataset.dims || '186,140,154').split(',');
      const scene = this.querySelector('.sn-pick-stage sn-scene');
      if (scene) {
        scene.style.setProperty('--bw', w); scene.style.setProperty('--bh', h); scene.style.setProperty('--bd', d);
        const lbl = scene.querySelector('[data-sn-label]'); if (lbl) lbl.textContent = tab.dataset.label;
      }
      const stage = this.querySelector('[data-stage]');
      if (stage) stage.style.setProperty('--glow', tab.dataset.glow);
      const word = this.querySelector('[data-word]'); if (word) word.textContent = tab.dataset.label;
      const badge = this.querySelector('[data-badge]');
      if (badge) { badge.textContent = tab.dataset.tag; badge.hidden = !tab.dataset.tag; }
    }
  }
  define('sn-box-picker', SnBoxPicker);

  /* ---------- Countdown zur nächsten Live-Show ---------- */
  class SnCountdown extends HTMLElement {
    connectedCallback() {
      this.days = (this.dataset.days || '').split(',').filter(Boolean).map(Number);
      const [h, m] = (this.dataset.time || '19:00').split(':').map(Number);
      this.h = isNaN(h) ? 19 : h; this.m = isNaN(m) ? 0 : m;
      this.duration = (Number(this.dataset.duration) || 120) * 60000;
      this.tick(); this.timer = setInterval(() => this.tick(), 1000);
    }
    disconnectedCallback() { clearInterval(this.timer); }
    next() {
      const now = new Date();
      for (let i = -1; i < 8; i++) {
        const t = new Date(now); t.setDate(now.getDate() + i); t.setHours(this.h, this.m, 0, 0);
        if (this.days.length && !this.days.includes(t.getDay())) continue;
        if (t.getTime() + this.duration > now.getTime()) return t;
      }
      return null;
    }
    tick() {
      const t = this.next(), now = Date.now();
      const clock = this.querySelector('.sn-clock:not(.sn-clock--live)'), live = this.querySelector('.sn-clock--live'), info = this.querySelector('[data-next]');
      if (!t) { clock.hidden = true; live.hidden = true; info.parentElement.hidden = true; return; }
      const isLive = t.getTime() <= now;
      clock.hidden = isLive; live.hidden = !isLive;
      const d = Math.max(0, t - now), pad = (v) => String(v).padStart(2, '0');
      this.querySelector('[data-h]').textContent = pad(Math.floor(d / 36e5));
      this.querySelector('[data-m]').textContent = pad(Math.floor((d % 36e5) / 6e4));
      this.querySelector('[data-s]').textContent = pad(Math.floor((d % 6e4) / 1e3));
      const today = t.toDateString() === new Date().toDateString();
      const day = today ? 'heute' : t.toLocaleDateString('de-DE', { weekday: 'long' });
      const pf = this.dataset.platform ? ' auf ' + this.dataset.platform : '';
      info.textContent = isLive ? 'Die Show läuft gerade' + pf : 'Nächste Show ' + day + ' um ' + pad(this.h) + ':' + pad(this.m) + pf;
    }
  }
  define('sn-countdown', SnCountdown);

  /* ---------- Live-Chat im Handy ---------- */
  class SnLiveChat extends HTMLElement {
    connectedCallback() {
      this.msgs = (this.dataset.msgs || '').split('|').map((s) => s.trim()).filter(Boolean);
      this.start = Number(this.dataset.bid) || 12; this.bid = this.start; this.i = 0;
      this.bidEl = this.parentElement && this.parentElement.querySelector('[data-bid-value]');
      if (!this.msgs.length) return;
      this.step(); this.step();
      if (!RM) this.iv = setInterval(() => this.step(), 1900);
    }
    disconnectedCallback() { clearInterval(this.iv); }
    step() {
      const raw = this.msgs[this.i++ % this.msgs.length];
      const k = raw.indexOf(':');
      const el = document.createElement('div');
      if (k > 0) { const b = document.createElement('b'); b.textContent = raw.slice(0, k); el.append(b, document.createTextNode(raw.slice(k + 1))); }
      else el.textContent = raw;
      this.append(el);
      while (this.children.length > 3) this.firstElementChild.remove();
      this.bid += Math.ceil(Math.random() * 3); if (this.bid > this.start * 4) this.bid = this.start;
      if (this.bidEl) this.bidEl.textContent = this.bid + ' €';
    }
  }
  define('sn-live-chat', SnLiveChat);

  /* ---------- Einkaufswagen öffnen / Zähler ---------- */
  const openCart = (trigger) => {
    const drawer = document.querySelector('cart-drawer');
    if (drawer && typeof drawer.open === 'function') { drawer.open(trigger); return true; }
    return false;
  };
  const money = (cents, cur) => {
    try { return new Intl.NumberFormat('de-DE', { style: 'currency', currency: cur || 'EUR' }).format(cents / 100); }
    catch (_) { return (cents / 100).toFixed(2).replace('.', ',') + ' €'; }
  };

  /* ---------- App-Leiste (Handy) ---------- */
  class SnTabbar extends HTMLElement {
    connectedCallback() {
      const always = this.hasAttribute('data-always') || DESIGN;
      const onScroll = () => this.classList.toggle('is-on', always || window.scrollY > 200);
      onScroll();
      this.onScroll = onScroll;
      window.addEventListener('scroll', onScroll, { passive: true });
      const cart = this.querySelector('[data-tab-cart]');
      if (cart) {
        cart.addEventListener('click', (e) => { if (openCart(cart)) e.preventDefault(); });
        if (typeof subscribe === 'function' && typeof PUB_SUB_EVENTS !== 'undefined') {
          this.unsub = subscribe(PUB_SUB_EVENTS.cartUpdate, () => this.refresh());
        }
        document.addEventListener('cart:updated', () => this.refresh());
      }
      const wheelBtn = this.querySelector('[data-tab-wheel]');
      if (wheelBtn && !document.querySelector('sn-wheel')) wheelBtn.hidden = true;
    }
    disconnectedCallback() {
      window.removeEventListener('scroll', this.onScroll);
      if (this.unsub) this.unsub();
    }
    refresh() {
      fetch((window.routes && window.routes.cart_url ? window.routes.cart_url : '/cart') + '.js', { headers: { Accept: 'application/json' } })
        .then((r) => r.json())
        .then((c) => {
          const n = this.querySelector('[data-count]'), t = this.querySelector('[data-total]'), l = this.querySelector('[data-count-label]');
          if (n) { n.textContent = c.item_count; n.classList.toggle('is-on', c.item_count > 0); n.classList.remove('bump'); void n.offsetWidth; n.classList.add('bump'); }
          if (t) t.textContent = c.item_count > 0 ? money(c.total_price, c.currency) : t.dataset.empty;
          if (l) l.textContent = c.item_count + ' Artikel';
        })
        .catch(() => {});
    }
  }
  define('sn-tabbar', SnTabbar);

  /* ---------- Glücksrad ---------- */
  class SnWheel extends HTMLElement {
    connectedCallback() {
      this.sheet = this.querySelector('.sn-sheet');
      this.overlay = this.querySelector('.sn-wheel__overlay');
      try { this.seg = JSON.parse(this.querySelector('[data-segments]').textContent); } catch (_) { this.seg = []; }
      this.key = 'sn-wheel-' + (this.dataset.sectionId || '');
      this.draw();
      this.onDoc = (e) => {
        const open = e.target.closest('[data-sn-wheel-open], a[href$="#gluecksrad"]');
        if (open) { e.preventDefault(); this.open(open); }
      };
      document.addEventListener('click', this.onDoc);
      this.querySelectorAll('[data-sn-wheel-close]').forEach((b) => b.addEventListener('click', () => this.close()));
      this.onKey = (e) => { if (e.key === 'Escape' && !this.sheet.hidden) this.close(); };
      document.addEventListener('keydown', this.onKey);
      this.querySelector('[data-spin]').addEventListener('click', () => this.spin());
      this.querySelector('[data-copy]').addEventListener('click', (e) => this.copy(e.currentTarget));
      if (this.dataset.once === 'true') {
        try { const saved = JSON.parse(localStorage.getItem(this.key) || 'null'); if (saved) this.showWin(saved, true); } catch (_) {}
      }
      if (location.hash === '#gluecksrad') this.open();
      if (DESIGN) {
        this.onSel = (e) => { if (e.detail && e.detail.sectionId === this.dataset.sectionId) this.open(); };
        this.onDesel = (e) => { if (e.detail && e.detail.sectionId === this.dataset.sectionId) this.close(); };
        document.addEventListener('shopify:section:select', this.onSel);
        document.addEventListener('shopify:section:deselect', this.onDesel);
      }
    }
    disconnectedCallback() {
      document.removeEventListener('click', this.onDoc);
      document.removeEventListener('keydown', this.onKey);
      if (this.onSel) { document.removeEventListener('shopify:section:select', this.onSel); document.removeEventListener('shopify:section:deselect', this.onDesel); }
      document.body.classList.remove('sn-lock');
    }
    draw() {
      const disc = this.querySelector('[data-disc]'), n = this.seg.length, R = 96;
      if (!disc || !n) return;
      const ns = 'http://www.w3.org/2000/svg';
      const p = (a) => `${(R * Math.cos(a)).toFixed(2)},${(R * Math.sin(a)).toFixed(2)}`;
      disc.innerHTML = '';
      this.seg.forEach((s, i) => {
        const a0 = (i / n) * 2 * Math.PI - Math.PI / 2 - Math.PI / n, a1 = a0 + (2 * Math.PI) / n;
        const mid = (((a0 + a1) / 2) * 180) / Math.PI;
        const path = document.createElementNS(ns, 'path');
        path.setAttribute('d', `M0,0 L${p(a0)} A${R},${R} 0 0,1 ${p(a1)} Z`);
        path.setAttribute('fill', s.color || '#FFD21F'); path.setAttribute('stroke', '#0B2414'); path.setAttribute('stroke-width', '1.2');
        disc.append(path);
        const g = document.createElementNS(ns, 'g');
        g.setAttribute('transform', `rotate(${mid}) translate(62,0) rotate(90)`);
        const text = document.createElementNS(ns, 'text');
        text.setAttribute('text-anchor', 'middle'); text.setAttribute('fill', s.fg || '#fff');
        const lines = String(s.label || '').length > 7 ? String(s.label).split(' ') : [String(s.label || '')];
        text.setAttribute('font-size', lines.length > 1 ? '11' : n > 10 ? '13' : '17');
        lines.forEach((l, j) => {
          const ts = document.createElementNS(ns, 'tspan');
          ts.setAttribute('x', '0'); ts.setAttribute('dy', j ? '12' : lines.length > 1 ? '-2' : '6'); ts.textContent = l;
          text.append(ts);
        });
        g.append(text); disc.append(g);
      });
      const ring = document.createElementNS(ns, 'circle');
      ring.setAttribute('r', '97'); ring.setAttribute('fill', 'none'); ring.setAttribute('stroke', '#0B2414'); ring.setAttribute('stroke-width', '2');
      disc.append(ring);
    }
    open(trigger) {
      this.trigger = trigger || document.activeElement;
      this.overlay.hidden = false; this.sheet.hidden = false;
      requestAnimationFrame(() => { this.classList.add('is-open'); });
      document.body.classList.add('sn-lock');
      setTimeout(() => this.sheet.focus({ preventScroll: true }), 50);
    }
    close() {
      this.classList.remove('is-open');
      document.body.classList.remove('sn-lock');
      setTimeout(() => { if (!this.classList.contains('is-open')) { this.overlay.hidden = true; this.sheet.hidden = true; } }, RM ? 0 : 500);
      if (this.trigger && this.trigger.focus) this.trigger.focus({ preventScroll: true });
    }
    pick() {
      const w = this.seg.map((s) => Math.max(0, Number(s.weight) || 0));
      const sum = w.reduce((a, b) => a + b, 0);
      if (!sum) return Math.floor(Math.random() * this.seg.length);
      let r = Math.random() * sum;
      for (let i = 0; i < w.length; i++) { r -= w[i]; if (r < 0) return i; }
      return 0;
    }
    spin() {
      if (this.spun || !this.seg.length) return;
      this.spun = true;
      const btn = this.querySelector('[data-spin]'); btn.disabled = true;
      const i = this.pick(), n = this.seg.length, jit = (Math.random() - 0.5) * (300 / n) * 0.8;
      const deg = 360 * 6 + (360 - i * (360 / n)) + jit;
      this.querySelector('[data-disc]').style.transform = `rotate(${deg}deg)`;
      const res = { prize: this.seg[i].prize, code: this.seg[i].code };
      setTimeout(() => {
        this.showWin(res);
        if (this.dataset.once === 'true') { try { localStorage.setItem(this.key, JSON.stringify(res)); } catch (_) {} }
      }, RM ? 50 : 4700);
    }
    showWin(res, restored) {
      this.spun = true;
      this.querySelector('[data-spin-area]').hidden = true;
      const win = this.querySelector('[data-win]');
      this.querySelector('[data-prize]').textContent = res.prize;
      this.querySelector('[data-code]').textContent = res.code;
      const root = (this.dataset.root || '/').replace(/\/$/, '');
      const redeem = this.querySelector('[data-redeem]');
      if (res.code) redeem.href = root + '/discount/' + encodeURIComponent(res.code) + '?redirect=' + encodeURIComponent(this.dataset.redirect || '/collections/all');
      win.hidden = false;
      if (!restored) win.classList.add('is-pop');
    }
    copy(btn) {
      const code = this.querySelector('[data-code]').textContent;
      const done = () => { btn.textContent = btn.dataset.done || '✓'; };
      if (navigator.clipboard) navigator.clipboard.writeText(code).then(done, done); else done();
    }
  }
  define('sn-wheel', SnWheel);

  /* ---------- Start ---------- */
  const init = () => observeReveal();
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
  document.addEventListener('shopify:section:load', (e) => observeReveal(e.target));
})();

/* Endloses Scrollen in Kollektionen: lädt automatisch die nächste Seite nach */
if (!customElements.get('sn-infinite')) {
  customElements.define('sn-infinite', class extends HTMLElement {
    connectedCallback() {
      this.loading = false;
      this.io = new IntersectionObserver((e) => { if (e[0].isIntersecting) this.load(); }, { rootMargin: '900px 0px' });
      this.io.observe(this);
      const btn = this.querySelector('a');
      if (btn) btn.addEventListener('click', (ev) => { ev.preventDefault(); this.load(); });
    }
    disconnectedCallback() { this.io && this.io.disconnect(); }
    async load() {
      const url = this.dataset.next;
      if (this.loading || !url) return;
      this.loading = true; this.classList.add('is-loading');
      try {
        const html = await (await fetch(url)).text();
        const doc = new DOMParser().parseFromString(html, 'text/html');
        const grid = document.getElementById('product-grid');
        const newGrid = doc.getElementById('product-grid');
        if (grid && newGrid) {
          newGrid.querySelectorAll(':scope > li').forEach((li) => {
            li.classList.remove('scroll-trigger', 'animate--slide-in');
            grid.appendChild(document.importNode(li, true));
          });
        }
        const next = doc.querySelector('sn-infinite');
        if (next && next.dataset.next) { this.dataset.next = next.dataset.next; this.querySelector('a').href = next.dataset.next; }
        else { this.io.disconnect(); this.remove(); return; }
      } catch (e) { /* bei Fehler bleibt der Button zum manuellen Nachladen */ }
      this.loading = false; this.classList.remove('is-loading');
    }
  });
}

/* Preise wie im Discounter: große Euro, kleine hochgestellte Cent (z. B. 1,⁹⁹ €) */
(function () {
  const RX = /^(\D*?)(\d{1,3}(?:\.\d{3})*|\d+),(\d{2})(\s*€?)$/;
  function fmt(el) {
    if (el.dataset.snP) return;
    const t = el.textContent.trim().replace(/ /g, ' ');
    const m = t.match(RX);
    if (!m) return;
    el.dataset.snP = '1';
    el.setAttribute('aria-label', t);
    el.innerHTML = '<span aria-hidden="true" class="sn-p"><span class="sn-p__e">' + m[2] + '</span><span class="sn-p__c">,' + m[3] + '</span><span class="sn-p__cur">' + (m[4].trim() || m[1].trim() || '€') + '</span></span>';
  }
  function run(root) { (root || document).querySelectorAll('.price-item--sale, .price__regular .price-item--regular, .sn-pick__price b, [data-sn-price]').forEach((el) => { if (el.tagName !== 'S' && !el.closest('s')) fmt(el); }); }
  document.addEventListener('DOMContentLoaded', () => run());
  new MutationObserver((ms) => ms.forEach((m) => m.addedNodes.forEach((n) => n.nodeType === 1 && run(n)))).observe(document.documentElement, { childList: true, subtree: true });
})();

/* Katalog-Ansicht (Groß / Kompakt / Liste) – merkt sich die Wahl */
(function () {
  const KEY = 'sn-view';
  function apply(v) {
    document.documentElement.dataset.snView = v;
    document.querySelectorAll('[data-sn-view]').forEach((b) => b.setAttribute('aria-pressed', b.dataset.snView === v));
  }
  let v = 'grid'; try { v = localStorage.getItem(KEY) || 'grid'; } catch (e) {}
  apply(v);
  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-sn-view]'); if (!b) return;
    apply(b.dataset.snView); try { localStorage.setItem(KEY, b.dataset.snView); } catch (err) {}
  });
  new MutationObserver(() => apply(document.documentElement.dataset.snView || 'grid')).observe(document.body || document.documentElement, { childList: true, subtree: true });
})();

/* Lieferdatum auf der Produktseite (bis 14 Uhr bestellt = Versand heute, 1–2 Werktage Zustellung) */
(function () {
  function addBiz(d, n) { const r = new Date(d); while (n > 0) { r.setDate(r.getDate() + 1); if (r.getDay() !== 0 && r.getDay() !== 6) n--; } return r; }
  function run() {
    const els = document.querySelectorAll('[data-sn-eta]'); if (!els.length) return;
    const now = new Date(); let ship = new Date(now);
    const weekend = now.getDay() === 0 || now.getDay() === 6;
    if (weekend || now.getHours() >= 14) ship = addBiz(now, 1);
    const a = addBiz(ship, 1), b = addBiz(ship, 2);
    const f = (d) => d.toLocaleDateString('de-DE', { weekday: 'short', day: '2-digit', month: '2-digit' });
    els.forEach((el) => { el.textContent = f(a) + ' – ' + f(b); });
    const left = new Date(now); left.setHours(14, 0, 0, 0);
    const mins = Math.round((left - now) / 60000);
    document.querySelectorAll('[data-sn-eta-hint]').forEach((h) => {
      h.textContent = (!weekend && mins > 0) ? 'Bestell in ' + Math.floor(mins / 60) + ' Std. ' + (mins % 60) + ' Min. – Versand noch heute' : 'Versand am nächsten Werktag';
    });
  }
  document.addEventListener('DOMContentLoaded', run);
})();

/* v12: Suche – wechselnder Platzhalter */
(function () {
  const inputs = document.querySelectorAll('[data-sn-rotate]'); if (!inputs.length) return;
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  inputs.forEach((inp) => {
    const words = inp.dataset.snRotate.split('|'); let i = 0;
    setInterval(() => { if (document.activeElement === inp || inp.value) return; i = (i + 1) % words.length; inp.placeholder = 'Suche z. B. „' + words[i] + '“'; }, 2600);
  });
})();

/* v12: Kompakter Header beim Scrollen + Nach-oben-Button */
(function () {
  const top = document.createElement('button');
  top.type = 'button'; top.className = 'sn-totop'; top.setAttribute('aria-label', 'Nach oben');
  top.innerHTML = '<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path d="m5 12 7-7 7 7M12 19V5" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  top.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  document.addEventListener('DOMContentLoaded', () => document.body.appendChild(top));
  let ticking = false;
  const on = () => { const y = window.scrollY; document.documentElement.classList.toggle('sn-scrolled', y > 140); top.classList.toggle('is-on', y > 900); ticking = false; };
  window.addEventListener('scroll', () => { if (!ticking) { ticking = true; requestAnimationFrame(on); } }, { passive: true });
})();

/* v12: Tab „Suche“ springt ins Suchfeld */
(function () {
  document.addEventListener('click', (e) => {
    const a = e.target.closest('a[href$="#suche"]'); if (!a) return;
    const inp = document.querySelector('#SnBandSearch') || document.querySelector('#SnHeaderSearch');
    if (!inp || location.pathname !== new URL(a.href, location.href).pathname) return;
    e.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' }); setTimeout(() => inp.focus(), 250);
  });
  if (location.hash === '#suche') document.addEventListener('DOMContentLoaded', () => { const i = document.querySelector('#SnBandSearch'); if (i) i.focus(); });
})();

/* v12: Zuletzt angesehen */
(function () {
  const KEY = 'sn-recent';
  const read = () => { try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch (e) { return []; } };
  const m = location.pathname.match(/\/products\/([^/?#]+)/);
  if (m) { try { const l = read().filter((h) => h !== m[1]); l.unshift(m[1]); localStorage.setItem(KEY, JSON.stringify(l.slice(0, 12))); } catch (e) {} }
  const eur = (c) => (c / 100).toLocaleString('de-DE', { style: 'currency', currency: 'EUR' });
  customElements.get('sn-recent') || customElements.define('sn-recent', class extends HTMLElement {
    async connectedCallback() {
      const cur = this.dataset.current; const handles = read().filter((h) => h && h !== cur).slice(0, 6);
      if (!handles.length) return;
      const list = this.querySelector('[data-list]');
      const items = await Promise.all(handles.map((h) => fetch((window.Shopify && Shopify.routes ? Shopify.routes.root : '/') + 'products/' + h + '.js').then((r) => (r.ok ? r.json() : null)).catch(() => null)));
      items.filter(Boolean).forEach((p) => {
        const img = p.featured_image ? p.featured_image.replace(/(\.[a-z]+)(\?|$)/i, '_300x300$1$2') : '';
        const li = document.createElement('li');
        li.innerHTML = '<a class="sn-recent__card" href="' + p.url + '">' + (img ? '<img src="' + img + '" alt="" width="150" height="150" loading="lazy">' : '') + '<span class="sn-recent__t"></span><b>' + eur(p.price) + '</b></a>';
        li.querySelector('.sn-recent__t').textContent = p.title;
        list.appendChild(li);
      });
      if (list.children.length) this.hidden = false;
    }
  });
})();

/* v12: Lieferdatum auch im Einkaufswagen (nach jedem Neuladen des Korbs) */
(function () {
  function addBiz(d, n) { const r = new Date(d); while (n > 0) { r.setDate(r.getDate() + 1); if (r.getDay() !== 0 && r.getDay() !== 6) n--; } return r; }
  function fill() {
    const now = new Date(); let ship = new Date(now);
    if (now.getDay() === 0 || now.getDay() === 6 || now.getHours() >= 14) ship = addBiz(now, 1);
    const f = (d) => d.toLocaleDateString('de-DE', { weekday: 'short', day: '2-digit', month: '2-digit' });
    const txt = f(addBiz(ship, 1)) + ' – ' + f(addBiz(ship, 2));
    document.querySelectorAll('[data-sn-eta]').forEach((el) => { if (el.textContent !== txt) el.textContent = txt; });
  }
  document.addEventListener('DOMContentLoaded', () => {
    fill();
    const d = document.querySelector('cart-drawer'); if (d) new MutationObserver(fill).observe(d, { childList: true, subtree: true });
  });
})();

/* v13: Schnapper des Tages – wechselt täglich um 0 Uhr, Countdown bis Mitternacht */
customElements.get('sn-daily') || customElements.define('sn-daily', class extends HTMLElement {
  connectedCallback() {
    const items = [...this.querySelectorAll('[data-sn-daily-item]')];
    if (items.length) {
      const now = new Date(); const day = Math.floor((now - new Date(now.getFullYear(), 0, 0)) / 864e5) + now.getFullYear() * 366;
      const pick = day % items.length; items.forEach((el, i) => { el.hidden = i !== pick; });
    }
    const out = this.querySelector('[data-sn-countdown]'); if (!out) return;
    const tick = () => {
      const n = new Date(); const m = new Date(n); m.setHours(24, 0, 0, 0);
      let s = Math.max(0, Math.floor((m - n) / 1000)); const h = Math.floor(s / 3600); s -= h * 3600; const mi = Math.floor(s / 60); s -= mi * 60;
      out.textContent = [h, mi, s].map((x) => String(x).padStart(2, '0')).join(':');
    };
    tick(); this._t = setInterval(tick, 1000);
  }
  disconnectedCallback() { clearInterval(this._t); }
});

/* v13: „Neu seit deinem letzten Besuch“ + Live&Deals-Button */
(function () {
  const KEY = 'sn-last-visit';
  document.addEventListener('DOMContentLoaded', async () => {
    const bar = document.querySelector('[data-sn-newbar]');
    let last = 0; try { last = +localStorage.getItem(KEY) || 0; } catch (e) {}
    const now = Date.now();
    // Besuch erst nach 30 Min. Pause als „neu“ zählen
    let seen = 0; try { seen = +sessionStorage.getItem(KEY) || 0; } catch (e) {}
    if (!seen) { try { sessionStorage.setItem(KEY, String(last || now)); localStorage.setItem(KEY, String(now)); } catch (e) {} seen = last; }
    if (bar && seen && now - seen > 30 * 60000 && !sessionStorage.getItem('sn-newbar-closed')) {
      try {
        const r = await fetch((window.Shopify && Shopify.routes ? Shopify.routes.root : '/') + 'products.json?limit=250');
        const { products } = await r.json();
        const n = products.filter((p) => new Date(p.published_at || p.created_at).getTime() > seen).length;
        if (n > 0) { bar.querySelector('[data-n]').textContent = n; bar.hidden = false; }
      } catch (e) {}
    }
    if (bar) bar.querySelector('[data-close]').addEventListener('click', () => { bar.hidden = true; try { sessionStorage.setItem('sn-newbar-closed', '1'); } catch (e) {} });
    const d = document.querySelector('[data-sn-dealsbtn]');
    if (d) {
      document.addEventListener('click', (e) => { if (d.open && !d.contains(e.target) && !e.target.closest('a[href$="#deals"]')) d.open = false; });
      document.addEventListener('keydown', (e) => { if (e.key === 'Escape') d.open = false; });
      d.querySelectorAll('a').forEach((a) => a.addEventListener('click', () => { d.open = false; }));
    }
  });
})();

/* v13: Tab „Deals“ öffnet die Live-&-Deals-Auswahl */
document.addEventListener('click', (e) => {
  const a = e.target.closest('a[href$="#deals"]'); if (!a) return;
  const d = document.querySelector('[data-sn-dealsbtn]'); if (!d) return;
  e.preventDefault(); e.stopPropagation(); d.open = !d.open;
}, true);
